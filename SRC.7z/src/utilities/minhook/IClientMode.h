#pragma once

class IClientMode
{
};
