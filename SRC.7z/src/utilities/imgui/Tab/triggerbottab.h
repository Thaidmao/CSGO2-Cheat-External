#pragma once

#include "../atgui.h"

namespace Triggerbot
{
	void RenderTab();
}