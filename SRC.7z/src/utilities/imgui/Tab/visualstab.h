#pragma once

#include "../atgui.h"

namespace Visuals
{
	void RenderTab();
}